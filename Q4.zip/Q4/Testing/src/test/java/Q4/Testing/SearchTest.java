package Q4.Testing;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SearchTest {
    private WebDriver driver;

    @Before
    public void setup() {
        System.setProperty("webdriver.chrome.driver", "/path/to/chromedriver");
        driver = new ChromeDriver();
        driver.get("https://magento.softwaretestingboard.com/");
    }

    @Test
    public void searchShirt() {
        WebElement searchBox = driver.findElement(By.name("q"));
        searchBox.sendKeys("Shirt");
        searchBox.submit();

        String title = driver.getTitle();
        System.out.println("Page title: " + title);
        assert title.contains("Search results for 'Shirt'");
    }

    @After
    public void tearDown() {
        driver.quit();
    }
}